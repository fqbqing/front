/**
 * ETPL (Enterprise Template)
 * Copyright 2013 Baidu Inc. All rights reserved.
 * 
 * @file Node入口
 * @author firede(firede@firede.us)
 */

module.exports = require('./src/main');
