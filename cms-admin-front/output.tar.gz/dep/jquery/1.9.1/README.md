http://jquery.com

针对jQuery的代码进行了一些小的调整：

1. AMD module
2. 去掉对全局变量的影响
