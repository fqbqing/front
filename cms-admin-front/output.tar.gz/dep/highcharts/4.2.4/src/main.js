/**
 * Created by lifayu on 15/5/8.
 */

define(function (require) {

    var Highcharts = require('./highstock');

    return Highcharts;
});