# Enterprise Simple UI library

## 文档

    cd {esui}
    sudo gem install jsduck
    jsduck —-config=jsduck/config.json
    open doc/api/index.html
